"""
===========================
Merging group of instances
===========================

This example demonstrate how to merge group of instances in the design

"""

from os import path
import spydrnet as sdn
import spydrnet_physical as sdnphy

# TODO
print("NotImplemented")