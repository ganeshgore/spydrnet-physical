"""
===================================
Merging two instances in the design
===================================

This example demonstrate how to merge two instance of the design

"""

from os import path
import spydrnet as sdn
import spydrnet_physical as sdnphy

# TODO
print("NotImplemented")