"""
===================================
Renaming Homogeneous FPGA Modules
===================================

Demonstrates how to rename FPGA modules

"""

from os import path
import spydrnet as sdn
import spydrnet_physical as sdnphy

# TODO
print("NotImplemented")