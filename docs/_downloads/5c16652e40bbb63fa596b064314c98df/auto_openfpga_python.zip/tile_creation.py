"""
=========================================
Creating FPGA Tiles from OpenFPGA verilog
=========================================

This example demonstate how to create a tile strcuture from
Verilog netlist obtained from OpenFPGA

"""

from os import path
import spydrnet as sdn
import spydrnet_physical as sdnphy

# TODO
print("NotImplemented")