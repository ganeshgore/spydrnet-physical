"""
=================================
Extract configuration chain order 
=================================

This example demonstrate how to extract configuration chain order from
the restructured netlist

"""

from os import path
import spydrnet as sdn
import spydrnet_physical as sdnphy

# TODO
print("NotImplemented")
